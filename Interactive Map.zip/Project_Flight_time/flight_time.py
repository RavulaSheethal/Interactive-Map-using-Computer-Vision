# Import necessary libraries
import pickle  # Pickle library for serializing Python objects
import cv2  # OpenCV library for computer vision tasks
import cvzone
import numpy as np  # NumPy library for numerical operations
from cvzone.HandTrackingModule import HandDetector

######################################
cam_id = 0
width, height = 1920, 1080
map_file_path = "../Step-1GetCornerPoints/map.p"
countries_file_path = "../Step-2GetCountryPolygons/countries.p"
######################################

file_obj = open(map_file_path, 'rb')
map_points = pickle.load(file_obj)
file_obj.close()
print(f"Loaded map coordinates.")


if countries_file_path:
    file_obj = open(countries_file_path, 'rb')
    polygons = pickle.load(file_obj)
    file_obj.close()
    print(f"Loaded {len(polygons)} countries.")
else:
    polygons = []

# Open a connection to the webcam
cap = cv2.VideoCapture(cam_id)  # For Webcam
# Set the width and height of the webcam frame
cap.set(3, width)
cap.set(4, height)
counter = 0


detector = HandDetector(staticMode=False,maxHands=2, modelComplexity=1, detectionCon=0.5, minTrackCon=0.5)


flight_time_list = [["India", "Afghanistan", "1.11 hours"], ["India", "Albania", "5.83 hours"], ["India", "Algeria", "7.84 hours"], ["India", "Andorra", "7.44 hours"],
["India", "Angola", "8.79 hours"],
["India", "Antigua and Barbuda", "14.56 hours"],
["India", "Argentina", "17.31 hours"],
["India", "Armenia", "15.25 hours"],
["India", "Australia", "11.35 hours"],
["India", "Austria", "6.1 hours"],
["India", "Azerbaijan", "3.08 hours"],
					["India", "Bahamas", "14.74 hours"],
					["India", "Bahrain", "2.89 hours"],
					["India", "Bangladesh", "1.56 hours"],
					["India", "Barbados", "14.74 hours"],
					["India", "Belarus", "5.08 hours"],
					["India", "Belgium", "7.03 hours"],
					["India", "Belize", "16.1 hours"],
					["India", "Benin" , "8.94 hours"],
					["India", "Bhutan", "1.34 hours"],
					["India", "Bolivia", "17.78 hours"],
					["India", "Bosnia and Herzegovina", "5.93 hours"],
					["India", "Botswana", "8.85 hours"],
					["India", "Brazil", "15.6 hours"],
					["India", "Brunei", "5.23 hours"],
					["India", "Bulgaria", "5.5 hours"],
					["India", "Burkina Faso", "9.06 hours"],
					["India", "Burundi", "6.77 hours"],
					["India", "Côte d'Ivoire", "9.77 hours"],
					["India", "Cabo Verde", "11.21 hours"],
					["India", "Cambodia", "3.77 hours"],
					["India", "Cameroon", "8.15 hours"],
					["India", "Canada", "12.42 hours"],
					["India", "Central African Republic", "7.38 hours"],
					["India", "Chad", "8.9 hours"],
					["India", "Chile", "18.54 hours"],
					["India", "China", "4.14 hours"],
					["India", "Colombia", "16.67 hours"],
					["India", "Comoros", "6.33 hours"],
					["India", "Costa Rica", "16.74 hours"],
					["India", "Croatia", "6.14 hours"],
					["India", "Cuba", "15.19 hours"],
					["India", "Cyprus", "4.57 hours"],
					["India", "Czechia (Czech Republic)", "6.25 hours"],
					["India", "Democratic Republic of the Congo", "8.25 hours"],
					["India", "Denmark", "6.41 hours"],
					["India", "Djibouti", "4.39 hours"],
					["India", "Dominica", "14.69 hours"],
					["India", "Dominican Republic", "15.01 hours"],
					["India", "Ecuador", "17.46 hours"],
					["India", "Egypt", "4.85 hours"],
					["India", "El Salvador", "16.53 hours"],
					["India", "Equatorial Guinea", "8.45 hours"],
					["India", "Eritrea", "4.59 hours"],
					["India", "Estonia", "5.7 hours"],
					["India", "Eswatini", "8.59 hours"],
					["India", "Ethiopia", "5 hours"],
					["India", "Fiji", "13.18 hours"],
					["India", "Finland", "5.72 hours"],
					["India", "France", "7.22 hours"],
					["India", "Gabon", "8.58 hours"],
					["India", "Gambia", "10.58 hours"],
					["India", "Georgia", "3.57 hours"],
					["India", "Germany", "6.34 hours"],
					["India", "Ghana", "9.3 hours"],
					["India", "Green Land", "9.7 hours"],
					["India", "Greece", "5.49 hours"],
					["India", "Grenada", "15.01 hours"],
					["India", "Guatemala", "16.47 hours"],
					["India", "Guinea", "10.51 hours"],
					["India", "Guinea-Bissau", "10.57 hours"],
					["India", "Guyana", "15.15 hours"],
					["India", "Haiti", "15.16 hours"] ,
					["India", "Honduras", "16.41 hours"],
					["India", "Hungary", "5.88 hours"],
					["India", "Iceland", "8.32 hours"],
					["India", "Indonesia", "5.48 hours"],
					["India", "Iran", "2.79 hours"],
					["India", "Iraq", "3.46 hours"],
					["India", "Ireland", "7.75 hours"],
					["India", "Israel", "4.41 hours"],
					["India", "Italy", "6.48 hours"],
					["India", "Jamaica", "15.48 hours"],
					["India", "Japan", "7.52 hours"],
					["India", "Jordan", "4.34 hours"],
					["India", "Kazakhstan", "2.79 hours"],
					["India", "Kenya", "5.96 hours"],
					["India", "Kiribati", "11.5 hours"],
					["India", "Kuwait", "3.11 hours"],
					["India", "Kyrgyzstan", "1.76 hours"],
					["India", "Laos", "3.12 hours"],
					["India", "Latvia", "5.66 hours"],
					["India", "Lebanon", "4.36 hours"],
					["India", "Lesotho", "9.13 hours"],
					["India", "Liberia", "10.39 hours"],
					["India", "Libya", "6.62 hours"],
					["India", "Liechtenstein", "6.67 hours"],
					["India", "Lithuania", "5.52 hours"],
					["India", "Luxembourg", "6.91 hours"],
					["India", "Madagascar", "6.77 hours"],
					["India", "Malawi", "7.29 hours"],
					["India", "Malaysia", "4.21 hours"],
					["India", "Maldives", "3.01 hours"],
					["India", "Mali", "11.2 hours"],
					["India", "Malta", "6.41 hours"],
					["India", "Marshall Islands", "11 hours"],
					["India", "Mauritania", "10.25 hours"],
					["India", "Mauritius", "6.38 hours"],
					["India", "Mexico", "16.06 hours"],
					["India", "Micronesia", "9.6 hours"],
					["India", "Moldova", "5.07 hours"],
					["India", "Monaco", "6.9 hours"],
					["India", "Mongolia", "3.65 hours"],
					["India", "Montenegro", "5.87 hours"],
					["India", "Morocco", "8.52 hours"],
					["India", "Mozambique", "8.46 hours"],
					["India", "Myanmar", "2.36 hours"],
					["India", "Namibia", "9.42 hours"],
					["India", "Nauru", "10.97 hours"],
					["India", "Nepal", "0.88 hours"],
					["India", "Netherlands", "6.96 hours"],
					["India", "New Zealand", "13.86 hours"],
					["India", "Nicaragua", "16.6 hours"],
					["India", "Niger", "8.61 hours"],
					["India", "Nigeria", "8.28 hours"],
					["India", "North Korea", "5.01 hours"],
					["India", "North Macedonia", "5.68 hours"],
					["India", "Norway", "6.56 hours"],
					["India", "Oman", "2.12 hours"],
					["India", "Pakistan", "0.75 hours"],
					["India", "Palau", "7.06 hours"],
					["India", "Palestine", "4.58 hours"],
					["India", "Panama", "16.6 hours"],
					["India", "Papua New Guinea", "9.44 hours"],
					["India", "Paraguay", "17.04 hours"],
					["India", "Peru", "18.38 hours"],
					["India", "Philippines", "5.21 hours"],
					["India", "Poland", "5.77 hours"],
					["India", "Portuagal", "8.52 hours"],
					["India", "Qatar", "2.81 hours"],
					["India", "Romania", "5.26 hours"],
					["India", "Russia", "4.76 hours"],
					["India", "Rwanda", "6.65 hours"],
					["India", "Saint Kitts and Nevis", "14.61 hours"],
					["India", "Saint Lucia", "14.78 hours"],
					["India", "Saint Vincent and the Grenadines", "14.87 hours"],
					["India", "Samoa", "14 hours"],
					["India", "San Marino", "6.46 hours"],
					["India", "Sao Tome and Principe", "8.87 hours"],
					["India", "Saudi Arabia", "3.35 hours"],
					["India", "Senegal", "10.6 hours"],
					["India", "Serbia", "5.75 hours"],
					["India", "Seychelles", "4.79 hours"],
					["India", "Sierra Leone", "10.52 hours"],
					["India", "Singapore", "4.55 hours"],
					["India", "Slovakia", "6.04 hours"],
					["India", "Slovenia", "6.26 hours"],
					["India", "Solomon Islands", "10.75 hours"],
					["India", "Somalia", "4.92 hours"],
					["India", "South Africa", "8.76 hours"],
					["India", "South Korea", "5.14 hours"],
					["India", "South Sudan", "6.01 hours"],
					["India", "Spain", "7.97 hours"],
					["India", "Sri Lanka", "2.67 hours"],
					["India", "Sudan", "5.26 hours"],
					["India", "Suriname", "14.95 hours"],
					["India", "Sweden", "8.43 hours"],
					["India", "Switzerland", "8.59 hours"],

					["India", "Syria", "5.40 hours"],
					["India", "Tajikistan", "2.45 hours"],
					["India", "Tanzania", "18.26 hours"],
					["India", "Thailand", "3.2 hours"],
					["India", "Timor-Leste", "7.27 hours"],
					["India", "Togo", "9.11 hours"],
					["India", "Tonga", "16.8 hours"],
					["India", "Trinidad and Tobago", "15.11 hours"],
					["India", "Tunisia", "6.81 hours"],
					["India", "Turkey", "4.62 hours"],
					["India", "Turkmenistan", "2.22 hours"],
					["India", "Tuvalu", "12.74 hours"],
					["India", "Uganda", "6.23 hours"],
					["India", "Ukraine", "5.02 hours"],
					["India", "United Arab Emirates", "2.54 hours"],
					["India", "United Kingdom", "7.35 hours"],
					["India", "United States of America", "13.2 hours"],
					["India", "Uruguay", "17.09 hours"],
					["India", "Uzbekistan", "1.74 hours"],
					["India", "Vanuatu", "12.1 hours"],
					["India", "Vatican City", "6.49 hours"],
					["India", "Venezuela", "15.56 hours"],
					["India", "Vietnam", "3.29 hours"],
					["India", "Yemen", "4.05 hours"],
					["India", "Zambia", "7.88 hours"],
					["India", "Zimbabwe", "7.85 hours"],]

def warp_image(img, points, size=[1920, 1080]):
    """
    Warps an image based on the selected points.

    Args:
        img: The image to be warped
        points: Array containing four clicked points
        size: Desired size of the warped image

    Returns:
        imgOutput: The warped image
        matrix: The perspective transformation matrix
    """
    pts1 = np.float32(points)
    pts2 = np.float32([[0, 0], [size[0], 0], [0, size[1]], [size[0], size[1]]])
    matrix = cv2.getPerspectiveTransform(pts1, pts2)  # Calculate perspective transformation matrix
    imgOutput = cv2.warpPerspective(img, matrix, (size[0], size[1]))  # Warp the image
    return imgOutput, matrix


def warp_single_point(point, matrix):
    """
    Warp a single point using the provided perspective transformation matrix.

    Parameters:
    - point: Coordinates of the point to be warped.
    - matrix: Perspective transformation matrix.

    Returns:
    - point_warped: Warped coordinates of the point.
    """
    # Convert the point to homogeneous coordinates
    point_homogeneous = np.array([[point[0], point[1], 1]], dtype=np.float32)

    # Apply the perspective transformation to the point
    point_homogeneous_transformed = np.dot(matrix, point_homogeneous.T).T

    # Convert back to non-homogeneous coordinates
    point_warped = point_homogeneous_transformed[0, :2] / point_homogeneous_transformed[0, 2]
    point_warped = int(point_warped[0]), int(point_warped[1])

    return point_warped

def inverse_warp_image(img, imgOverlay, map_points):
    """
    Inverse warp an overlay image onto the original image using provided map points.

    Parameters:
    - img: Original image.
    - imgOverlay: Overlay image to be warped.
    - map_points: List of four points representing the region on the map.

    Returns:
    - result: Combined image with the overlay applied.
    """
    # Convert map_points to NumPy array
    map_points = np.array(map_points, dtype=np.float32)

    # Define the destination points for the overlay image
    destination_points = np.array([[0, 0], [imgOverlay.shape[1] - 1, 0], [0, imgOverlay.shape[0] - 1],
                                   [imgOverlay.shape[1] - 1, imgOverlay.shape[0] - 1]], dtype=np.float32)

    # Calculate the perspective transform matrix
    M = cv2.getPerspectiveTransform(destination_points, map_points)

    # Warp the overlay image to fit the perspective of the original image
    warped_overlay = cv2.warpPerspective(imgOverlay, M, (img.shape[1], img.shape[0]))

    # Combine the original image with the warped overlay
    result = cv2.addWeighted(img, 1, warped_overlay, 0.65, 0, warped_overlay)

    return result


def get_finger_location(img, imgWarped):
    """
    Get the location of the index finger tip in the warped image.

    Parameters:
    - img: Original

 image.

    Returns:
    - warped_point: Coordinates of the index finger tip in the warped image.
    """
    # Find hands in the current frame
    hands, img = detector.findHands(img, draw=False, flipType=True)


    # Check if any hands are detected
    if hands:
        # Information for the first hand detected
        hand1 = hands[0]  # Get the first hand detected
        indexFinger = hand1["lmList"][8][0:2]  # List of 21 landmarks for the first hand
        # cv2.circle(img,indexFinger,5,(255,0,255,),cv2.FILLED)
        warped_point = warp_single_point(indexFinger, matrix)
        warped_point = int(warped_point[0]), int(warped_point[1])
        print(indexFinger, warped_point)
        cv2.circle(imgWarped, warped_point, 10, (255, 0, 0), cv2.FILLED)
        if len(hands) == 2:
            hand2 = hands[1]  # Get the first hand detected
            indexFinger2 = hand2["lmList"][8][0:2]  # List of 21 landmarks for the first hand
            warped_point2 = warp_single_point(indexFinger2, matrix)
            cv2.circle(imgWarped, warped_point2, 10, (255, 0, 255), cv2.FILLED)
            warped_point = [warped_point, warped_point2]
    else:
        warped_point = None

    return warped_point


def create_overlay_image(polygons, warped_point, imgOverlay):
    """
    Create an overlay image with marked polygons based on the warped finger location.

    Parameters:
    - polygons: List of polygons representing countries.
    - warped_point: Coordinates of the index finger tip in the warped image.
    - imgOverlay: Overlay image to be marked.

    Returns:
    - imgOverlay: Overlay image with marked polygons.
    """


    if isinstance(warped_point, list):
        check = []
        for warp_point in warped_point:
            for polygon, name in polygons:
                polygon_np = np.array(polygon, np.int32).reshape((-1, 1, 2))
                result = cv2.pointPolygonTest(polygon_np, warp_point, False)
                if result >= 0:
                    cv2.polylines(imgOverlay, [np.array(polygon)], isClosed=True, color=(0, 255, 0), thickness=2)
                    cv2.fillPoly(imgOverlay, [np.array(polygon)], (0, 255, 0))
                    cvzone.putTextRect(imgOverlay, name, polygon[0], scale=1, thickness=1)
                    cvzone.putTextRect(imgOverlay, name, (0, 100), scale=5, thickness=5)
                    check.append(name)
        if len(check) == 2:
            cv2.line(imgOverlay, warped_point[0], warped_point[1], (0, 255, 0), 10)
            for flight_time in flight_time_list:
                if check[0] in flight_time and check[1] in flight_time:
                    cvzone.putTextRect(imgOverlay, flight_time[0] + " to " +  flight_time[1], (0, 100), scale=8,
                                       thickness=5)
                    cvzone.putTextRect(imgOverlay, flight_time[2], (0, 200), scale=8, thickness=5)

    else:
    # loop through all the countries
        for polygon, name in polygons:
            polygon_np = np.array(polygon, np.int32).reshape((-1, 1, 2))
            result = cv2.pointPolygonTest(polygon_np, warped_point, False)
            if result >= 0:
                cv2.polylines(imgOverlay, [np.array(polygon)], isClosed=True, color=(0, 255, 0), thickness=2)
                cv2.fillPoly(imgOverlay, [np.array(polygon)], (0, 255, 0))
                cvzone.putTextRect(imgOverlay, name, polygon[0], scale=1, thickness=1)
                cvzone.putTextRect(imgOverlay, name, (0, 100), scale=8, thickness=5)
        # cv2.imshow("Overlay", imgOverlay)

    return imgOverlay

while True:
    success, img = cap.read()
    imgWarped, matrix = warp_image(img, map_points)
    imgOutput = img.copy()


    # Find the hand and its Landmark
    warped_point = get_finger_location(img,imgWarped)

    h, w, _ = imgWarped.shape
    imgOverlay = np.zeros((h, w, 3), dtype=np.uint8)

    if warped_point:
        imgOverlay = create_overlay_image(polygons, warped_point, imgOverlay)
    #     imgOutput = inverse_warp_image(img, imgOverlay, map_points)


    imgStacked = cvzone.stackImages([imgOutput, imgOverlay],2, 0.3)
    cv2.imshow("Stacked Image", imgStacked)

    # cv2.imshow("Original Image", img)
    # cv2.imshow("Warped Image", imgWarped)
    # cv2.imshow("Output Image", imgOutput)
    key = cv2.waitKey(1)

